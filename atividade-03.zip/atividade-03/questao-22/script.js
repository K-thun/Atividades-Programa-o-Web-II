function validarProduto(p) {
  const erros = [];
  if (!p.nome.trim()) erros.push("Nome não pode ser vazio");
  if (p.preco <= 0) erros.push("Preço deve ser maior que zero");
  if (!p.categoria.trim()) erros.push("Categoria não pode ser vazia");
  return { ok: erros.length === 0, erros };
}

const form = document.querySelector("#formProduto");
const divErros = document.querySelector("#erros");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const p = {
    nome: document.querySelector("#nome").value,
    preco: Number(document.querySelector("#preco").value),
    categoria: document.querySelector("#categoria").value
  };

  const { ok, erros } = validarProduto(p);

  divErros.innerHTML = "";
  form.classList.toggle("error", !ok);

  if (!ok) {
    const ul = document.createElement("ul");
    erros.forEach(msg => {
      const li = document.createElement("li");
      li.textContent = msg;
      ul.appendChild(li);
    });
    divErros.appendChild(ul);
  }
});
