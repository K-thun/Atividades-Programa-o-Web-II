Undefined é quando um valor não é definido. O valor não é zerado, somente marcado como não declarado.
Null é quando um valor propositalmente é declarado como vazio. Quando convertido em número, conta como zero.
Falsy engloba essas classificações, além de valores falsos.