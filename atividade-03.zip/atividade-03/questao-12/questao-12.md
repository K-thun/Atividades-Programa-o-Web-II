Selecting: Selecionar o elemento do DOM a ser utilizado.
Binding: Ligar um elemento a um evento.
Callback: Função executada quando o evento ocorrer.