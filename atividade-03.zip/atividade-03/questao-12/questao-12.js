const form = document.querySelector("#formLogin");
const emailInput = document.querySelector("#email");

form.addEventListener("submit", function (e) {
  e.preventDefault(); 
  if (emailInput.value.trim() === "") {
    emailInput.classList.add("error"); 
  } else {
    emailInput.classList.remove("error");
  }
});
