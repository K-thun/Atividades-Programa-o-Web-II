//Compose aplica as funções da direita para a esquerda.
//Pipe aplica da esquerda para a direita.

const compose = (f, g) => x => f(g(x));
const resultadoCompose = compose(somar1, dup)(5); 

const pipe = (f, g) => x => g(f(x));
const resultadoPipe = pipe(somar1, dup)(5);
