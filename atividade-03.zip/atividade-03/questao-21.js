function createCounter() {
  let count = 0;

  return {
    increment() {
      count++;
    },
    
    getCount() {
      return count;
    }
  };
}

const counter = createCounter();
counter.increment();
console.log(counter.getCount());

//Significa que a função mantém acesso às variáveis do escopo onde foi criada, mesmo após esse escopo já ter terminado.