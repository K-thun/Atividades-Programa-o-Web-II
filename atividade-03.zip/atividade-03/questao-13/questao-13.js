let log = [];
function dobra(x) {
  log.push(x);
  return x * 2;  
}

console.log(dobra(2));
console.log(dobra(2));
console.log(log);
