const ul = document.getElementById("lista");
const li = document.createElement("li");
li.textContent = "Item novo"; 
ul.append(li);
