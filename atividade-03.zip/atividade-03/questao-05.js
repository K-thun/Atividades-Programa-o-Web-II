function getUserNameOrLoginCTA(user) {
  return user.name || "<a href='/login'>Entrar</a>";
}

const user1 = {name: "Kauã"};
//falsy
const user2 = {name: ""};

console.log(getUserNameOrLoginCTA(user1));
console.log(getUserNameOrLoginCTA(user2));

//|| retorna verdadeiro se pelo menos um operador for verdadeiro. 
//&& retorna falso se os dois operadores forem falsos.
