//Mutável
const nums = [1, 2, 3];
nums.push(4);
console.log(nums);

//Imutável
const numeros = [1, 2, 3];
const novo = [...numerps, 4];
console.log(novo); 