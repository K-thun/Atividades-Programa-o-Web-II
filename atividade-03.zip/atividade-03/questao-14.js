// Porque quando recebe um array por parâmetro, ela recebe o array original.
// Logo, se a função modificar o array, pode causar um problema por estar mexendo diretamente no array externo.
function adicionarItemImutavel(arr, item) {
  return [...arr, item]; // cria um novo array
}
