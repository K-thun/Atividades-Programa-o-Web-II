Porque a declaração está errada. O certo é:
element.style.backgroundColor = "red";