function aplicarTaxa(taxa) {
  return function (valor) {
    return valor * (1 + taxa);
  };
}

//Currying transforma uma função com vários parâmetros em várias funções de um parâmetro, 
//permitindo aplicar só parte deles agora. Isso funciona porque a função retornada guarda os valores anteriores usando closures.