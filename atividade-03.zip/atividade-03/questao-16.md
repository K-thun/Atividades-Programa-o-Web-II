forEach(): percorre cada elemento do array.
map(): percorre o array e transforma cada elemento.
filter(): percorre o array e mantém apenas valores que atendem à condição.
reduce(): percorre o array acumulando valores em um único resultado.