//No lazy evaluation, o cálculo só é executado quando realmente é necessário, em vez de ser feito imediatamente.
//O cálculo fn(arr[i]) só acontece quando chamamos get(i).
//As vantagens são que não faz ocupar menos memória, requer menos CPU, e só calcula o que for realmente usado.