const map = pedidos.map(p => p.total);

const filter = pedidos.filter(p => p.total >= 200);

const reduce = pedidos.reduce((acc, p) => acc + p.total, 0);

//Porque eles apenas lêem o array e retornam um novo array de acordo com o anterior.
